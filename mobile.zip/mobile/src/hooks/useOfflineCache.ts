import { useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Task } from "../types";

const TASKS_KEY = "offline:tasks_v1";
const PENDING_KEY = "offline:pending_v1";

export interface PendingOp {
  id: string;
  type: "create" | "update" | "delete";
  data: Record<string, unknown>;
}

export function useOfflineCache() {
  const [cachedTasks, setCachedTasks] = useState<Task[]>([]);
  const [pendingOps, setPendingOps] = useState<PendingOp[]>([]);
  const [cacheLoaded, setCacheLoaded] = useState(false);

  useEffect(() => {
    Promise.all([
      AsyncStorage.getItem(TASKS_KEY),
      AsyncStorage.getItem(PENDING_KEY),
    ]).then(([tasksVal, pendingVal]) => {
      if (tasksVal) {
        try { setCachedTasks(JSON.parse(tasksVal)); } catch { /* ignore */ }
      }
      if (pendingVal) {
        try { setPendingOps(JSON.parse(pendingVal)); } catch { /* ignore */ }
      }
      setCacheLoaded(true);
    });
  }, []);

  const saveCache = useCallback((tasks: Task[]) => {
    setCachedTasks(tasks);
    AsyncStorage.setItem(TASKS_KEY, JSON.stringify(tasks)).catch(() => {});
  }, []);

  const addOp = useCallback((op: Omit<PendingOp, "id">): PendingOp => {
    const fullOp: PendingOp = { ...op, id: `${Date.now()}_${Math.random()}` };
    setPendingOps((prev) => {
      const next = [...prev, fullOp];
      AsyncStorage.setItem(PENDING_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
    return fullOp;
  }, []);

  const removeOp = useCallback((id: string) => {
    setPendingOps((prev) => {
      const next = prev.filter((op) => op.id !== id);
      AsyncStorage.setItem(PENDING_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  }, []);

  const clearAllOps = useCallback(() => {
    setPendingOps([]);
    AsyncStorage.removeItem(PENDING_KEY).catch(() => {});
  }, []);

  return {
    cachedTasks,
    pendingOps,
    cacheLoaded,
    saveCache,
    addOp,
    removeOp,
    clearAllOps,
  };
}
