import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { trpc } from "../api/client";
import { useNetworkStatus } from "./useNetworkStatus";
import { useOfflineCache, type PendingOp } from "./useOfflineCache";
import type { Task, Category } from "../types";

function applyPendingOps(tasks: Task[], ops: PendingOp[]): Task[] {
  let result = [...tasks];
  for (const op of ops) {
    if (op.type === "delete") {
      result = result.filter((t) => t.id !== (op.data.id as number));
    } else if (op.type === "create") {
      const tempId = -(Date.now() + Math.random());
      result = [
        ...result,
        {
          id: tempId,
          title: op.data.title as string,
          description: (op.data.description as string | undefined) ?? null,
          category: op.data.category as Category,
          taskDate: op.data.taskDate as string,
          userId: 0,
          createdAt: new Date().toISOString(),
        } as unknown as Task,
      ];
    } else if (op.type === "update") {
      result = result.map((t) =>
        t.id === (op.data.id as number)
          ? {
              ...t,
              ...(op.data.title !== undefined && { title: op.data.title as string }),
              ...(op.data.description !== undefined && { description: op.data.description as string }),
              ...(op.data.category !== undefined && { category: op.data.category as Category }),
              ...(op.data.taskDate !== undefined && { taskDate: op.data.taskDate as string }),
            }
          : t
      );
    }
  }
  return result;
}

export interface OfflineTaskSubmit {
  type: "create" | "update";
  data: {
    id?: number;
    title: string;
    description?: string;
    category: Category;
    taskDate: string;
  };
}

export function useOfflineTasks() {
  const { isOnline, isInitialized } = useNetworkStatus();
  const { cachedTasks, pendingOps, cacheLoaded, saveCache, addOp, removeOp } = useOfflineCache();
  const [isSyncing, setIsSyncing] = useState(false);
  const queryClient = useQueryClient();

  const tasksQuery = trpc.tasks.list.useQuery(undefined, {
    enabled: isOnline && isInitialized,
    staleTime: 30_000,
    retry: false,
  });

  useEffect(() => {
    if (tasksQuery.data) {
      saveCache(tasksQuery.data);
    }
  }, [tasksQuery.data, saveCache]);

  const deleteMutation = trpc.tasks.delete.useMutation();
  const createMutation = trpc.tasks.create.useMutation();
  const updateMutation = trpc.tasks.update.useMutation();

  const serverTasks = isOnline ? (tasksQuery.data ?? cachedTasks) : cachedTasks;
  const tasks = useMemo(() => applyPendingOps(serverTasks, pendingOps), [serverTasks, pendingOps]);

  const syncPending = useCallback(async () => {
    if (!isOnline || pendingOps.length === 0 || isSyncing) return;
    setIsSyncing(true);
    const opsToProcess = [...pendingOps];
    for (const op of opsToProcess) {
      try {
        if (op.type === "create") {
          await createMutation.mutateAsync({
            title: op.data.title as string,
            description: op.data.description as string | undefined,
            category: op.data.category as Category,
            taskDate: new Date(op.data.taskDate as string),
          });
          removeOp(op.id);
        } else if (op.type === "update" && op.data.id) {
          await updateMutation.mutateAsync({
            id: op.data.id as number,
            title: op.data.title as string | undefined,
            description: op.data.description as string | undefined,
            category: op.data.category as Category | undefined,
            taskDate: op.data.taskDate ? new Date(op.data.taskDate as string) : undefined,
          });
          removeOp(op.id);
        } else if (op.type === "delete") {
          await deleteMutation.mutateAsync({ id: op.data.id as number });
          removeOp(op.id);
        }
      } catch {
        /* keep op in queue, will retry next time */
      }
    }
    setIsSyncing(false);
    queryClient.invalidateQueries();
  }, [isOnline, pendingOps, isSyncing, createMutation, updateMutation, deleteMutation, removeOp, queryClient]);

  const prevOnlineRef = useRef(isOnline);
  useEffect(() => {
    if (!prevOnlineRef.current && isOnline && pendingOps.length > 0) {
      syncPending();
    }
    prevOnlineRef.current = isOnline;
  }, [isOnline, pendingOps.length, syncPending]);

  const deleteTask = useCallback(
    async (id: number) => {
      if (!isOnline) {
        addOp({ type: "delete", data: { id } });
        saveCache(cachedTasks.filter((t) => t.id !== id));
        return;
      }
      await deleteMutation.mutateAsync({ id });
      await tasksQuery.refetch();
    },
    [isOnline, deleteMutation, tasksQuery, addOp, cachedTasks, saveCache]
  );

  const submitTaskOffline = useCallback(
    (submit: OfflineTaskSubmit) => {
      const { type, data } = submit;
      addOp({
        type,
        data: {
          id: data.id,
          title: data.title,
          description: data.description,
          category: data.category,
          taskDate: data.taskDate,
        },
      });
    },
    [addOp]
  );

  const refetch = useCallback(async () => {
    if (isOnline) await tasksQuery.refetch();
  }, [isOnline, tasksQuery]);

  return {
    tasks,
    isLoading: (tasksQuery.isLoading && isOnline) || !cacheLoaded,
    isOnline,
    isSyncing,
    pendingCount: pendingOps.length,
    refetch,
    deleteTask,
    submitTaskOffline,
    syncPending,
  };
}
