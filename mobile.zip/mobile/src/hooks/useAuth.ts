import { useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { trpc } from "../api/client";

export function useAuth() {
  const { data: user, isLoading, refetch } = trpc.auth.me.useQuery(undefined, {
    retry: false,
  });

  const queryClient = useQueryClient();
  const logoutMutation = trpc.auth.logout.useMutation();

  const logout = useCallback(async () => {
    await logoutMutation.mutateAsync();
    queryClient.clear();
    refetch();
  }, [logoutMutation, queryClient, refetch]);

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    logout,
  };
}
