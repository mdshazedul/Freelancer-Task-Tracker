import { useEffect, useState } from "react";
import * as SecureStore from "expo-secure-store";

const DEVICE_ID_KEY = "deviceId";
const PIN_SETUP_KEY = "pinSetup";
const USER_PIN_KEY = "userPin";

export function useDevicePin() {
  const [deviceId, setDeviceId] = useState<string>("");
  const [pinSetup, setPinSetupState] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      let id = await SecureStore.getItemAsync(DEVICE_ID_KEY);
      if (!id) {
        id = `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        await SecureStore.setItemAsync(DEVICE_ID_KEY, id);
      }
      setDeviceId(id);

      const setup = await SecureStore.getItemAsync(PIN_SETUP_KEY);
      setPinSetupState(setup === "true");
      setLoading(false);
    }
    init();
  }, []);

  const setPinSetup = async (value: boolean) => {
    await SecureStore.setItemAsync(PIN_SETUP_KEY, value ? "true" : "false");
    setPinSetupState(value);
  };

  const storePin = async (pin: string) => {
    await SecureStore.setItemAsync(USER_PIN_KEY, pin);
  };

  const verifyPin = async (pin: string): Promise<boolean> => {
    const storedPin = await SecureStore.getItemAsync(USER_PIN_KEY);
    return storedPin === pin;
  };

  const clearPin = async () => {
    await SecureStore.deleteItemAsync(USER_PIN_KEY);
    await SecureStore.deleteItemAsync(PIN_SETUP_KEY);
    setPinSetupState(false);
  };

  return {
    deviceId,
    pinSetup,
    loading,
    setPinSetup,
    storePin,
    verifyPin,
    clearPin,
  };
}
