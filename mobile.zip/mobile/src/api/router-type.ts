import type { Category } from "../types";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface Task {
  id: number;
  userId: number;
  title: string;
  description: string | null;
  category: Category;
  taskDate: Date;
  filesData: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: number;
  openId: string;
  email: string | null;
  role: string;
}

export type AppRouter = {
  auth: {
    me: {
      _def: {
        $types: {
          input: void;
          output: User | null;
        };
      };
    };
    logout: {
      _def: {
        $types: {
          input: void;
          output: { success: true };
        };
      };
    };
  };
  devicePin: {
    setup: {
      _def: {
        $types: {
          input: { pin: string; deviceId: string };
          output: { success: boolean; message: string };
        };
      };
    };
    verify: {
      _def: {
        $types: {
          input: { pin: string; deviceId: string };
          output: { isValid: boolean };
        };
      };
    };
    check: {
      _def: {
        $types: {
          input: { deviceId: string };
          output: { hasPinSet: boolean };
        };
      };
    };
  };
  tasks: {
    list: {
      _def: {
        $types: {
          input: void;
          output: Task[];
        };
      };
    };
    create: {
      _def: {
        $types: {
          input: {
            title: string;
            description?: string;
            category: Category;
            taskDate: Date;
            filesData?: string;
          };
          output: Task;
        };
      };
    };
    update: {
      _def: {
        $types: {
          input: {
            id: number;
            title?: string;
            description?: string;
            category?: Category;
            taskDate?: Date;
            filesData?: string;
          };
          output: Task;
        };
      };
    };
    delete: {
      _def: {
        $types: {
          input: { id: number };
          output: void;
        };
      };
    };
    getById: {
      _def: {
        $types: {
          input: { id: number };
          output: Task | null;
        };
      };
    };
  };
  ai: {
    chat: {
      _def: {
        $types: {
          input: { messages: ChatMessage[] };
          output: { content: string };
        };
      };
    };
  };
};
