import { createTRPCReact } from "@trpc/react-query";
import type { AppRouter } from "./router-type";

export const trpc = createTRPCReact<AppRouter>();
