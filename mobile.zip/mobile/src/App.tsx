import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink } from "@trpc/client";
import SuperJSON from "superjson";
import { trpc } from "./api/client";
import { useDevicePin } from "./hooks/useDevicePin";
import HomeScreen from "./screens/HomeScreen";
import LoginScreen from "./screens/LoginScreen";
import PinSetupScreen from "./screens/PinSetupScreen";
import PinVerifyScreen from "./screens/PinVerifyScreen";
import DashboardScreen from "./screens/DashboardScreen";
import StatsScreen from "./screens/StatsScreen";
import AIChatScreen from "./screens/AIChatScreen";
import SettingsScreen from "./screens/SettingsScreen";

export const BASE_URL = "https://your-deployed-app.replit.app";

type Screen =
  | "home"
  | "login"
  | "pin-setup"
  | "pin-verify"
  | "dashboard"
  | "stats"
  | "ai-chat"
  | "settings";

const TAB_SCREENS_SET = new Set<Screen>(["dashboard", "stats", "ai-chat", "settings"]);

const TABS: { key: Screen; icon: string; label: string }[] = [
  { key: "dashboard", icon: "📋", label: "কাজ" },
  { key: "stats", icon: "📊", label: "স্ট্যাটস" },
  { key: "ai-chat", icon: "✨", label: "সহায় AI" },
  { key: "settings", icon: "⚙️", label: "সেটিংস" },
];

function AppContent() {
  const [screen, setScreen] = useState<Screen>("home");
  const [isPinVerified, setIsPinVerified] = useState(false);
  const { pinSetup, loading: pinLoading } = useDevicePin();

  const {
    data: user,
    isLoading: authLoading,
    refetch: refetchAuth,
  } = trpc.auth.me.useQuery(undefined, {
    retry: false,
    staleTime: 30000,
  });
  const logoutMutation = trpc.auth.logout.useMutation();

  useEffect(() => {
    if (authLoading || pinLoading) return;

    if (!user) {
      setScreen("home");
      return;
    }

    if (!pinSetup) {
      setScreen("pin-setup");
      return;
    }

    if (!isPinVerified) {
      setScreen("pin-verify");
      return;
    }

    // Keep current tab if already on a tab screen, else go to dashboard
    setScreen((prev) => (TAB_SCREENS_SET.has(prev) ? prev : "dashboard"));
  }, [user, authLoading, pinLoading, pinSetup, isPinVerified]);

  const handleLogout = useCallback(async () => {
    try {
      await logoutMutation.mutateAsync();
    } catch {}
    setIsPinVerified(false);
    setScreen("home");
    refetchAuth();
  }, [logoutMutation, refetchAuth]);

  const handlePinVerified = useCallback(() => {
    setIsPinVerified(true);
    setScreen("dashboard");
  }, []);

  const handlePinSetupComplete = useCallback(() => {
    setIsPinVerified(true);
    setScreen("dashboard");
  }, []);

  const handleResetPin = useCallback(() => {
    setIsPinVerified(false);
    setScreen("pin-setup");
  }, []);

  // ── Loading ──
  if (authLoading || pinLoading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#dc2626" />
        <Text style={styles.loadingText}>লোড হচ্ছে...</Text>
      </SafeAreaView>
    );
  }

  // ── Pre-auth screens ──
  if (screen === "home") {
    return <HomeScreen onLogin={() => setScreen("login")} baseUrl={BASE_URL} />;
  }
  if (screen === "login") {
    return (
      <LoginScreen baseUrl={BASE_URL} onLoginSuccess={() => refetchAuth()} />
    );
  }
  if (screen === "pin-setup") {
    return <PinSetupScreen onComplete={handlePinSetupComplete} />;
  }
  if (screen === "pin-verify") {
    return <PinVerifyScreen onVerified={handlePinVerified} />;
  }

  // ── Main tab layout ──
  if (!TAB_SCREENS_SET.has(screen)) return null;

  return (
    <View style={styles.mainContainer}>
      {/* Active Screen */}
      <View style={styles.flex}>
        {screen === "dashboard" && (
          <DashboardScreen userName={user?.email} onLogout={handleLogout} />
        )}
        {screen === "stats" && <StatsScreen />}
        {screen === "ai-chat" && <AIChatScreen />}
        {screen === "settings" && (
          <SettingsScreen
            user={user}
            onLogout={handleLogout}
            onResetPin={handleResetPin}
          />
        )}
      </View>

      {/* Bottom Tab Bar */}
      <View style={styles.tabBar}>
        {TABS.map((tab) => {
          const active = screen === tab.key;
          return (
            <TouchableOpacity
              key={tab.key}
              style={styles.tab}
              onPress={() => setScreen(tab.key)}
              activeOpacity={0.7}
            >
              <Text style={[styles.tabIcon, active && styles.tabIconActive]}>
                {tab.icon}
              </Text>
              <Text style={[styles.tabText, active && styles.tabTextActive]}>
                {tab.label}
              </Text>
              {active && <View style={styles.tabIndicator} />}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

export default function App() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { staleTime: 30000, retry: 1 },
        },
      })
  );

  const [trpcClient] = useState(() =>
    trpc.createClient({
      links: [
        httpBatchLink({
          url: `${BASE_URL}/api/trpc`,
          transformer: SuperJSON,
          fetch(url, options) {
            return fetch(url, { ...options, credentials: "include" });
          },
        }),
      ],
    })
  );

  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <AppContent />
      </QueryClientProvider>
    </trpc.Provider>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  loadingText: { marginTop: 12, color: "#6b7280", fontSize: 16 },
  mainContainer: { flex: 1, backgroundColor: "#f9fafb" },
  flex: { flex: 1 },
  tabBar: {
    flexDirection: "row",
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#f0f0f0",
    paddingBottom: 10,
    paddingTop: 6,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 8,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 2,
    gap: 2,
    position: "relative",
  },
  tabIcon: { fontSize: 20, opacity: 0.35 },
  tabIconActive: { opacity: 1 },
  tabText: { fontSize: 10, color: "#9ca3af", fontWeight: "500" },
  tabTextActive: { color: "#dc2626", fontWeight: "700" },
  tabIndicator: {
    position: "absolute",
    top: -6,
    width: 20,
    height: 3,
    backgroundColor: "#dc2626",
    borderRadius: 2,
  },
});
