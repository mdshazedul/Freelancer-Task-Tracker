export type Category = "learned" | "completed" | "in-progress";

export interface FileData {
  id: string;
  name: string;
  type: "image" | "video";
  data: string;
  size: number;
}

export interface Task {
  id: number;
  userId: number;
  title: string;
  description: string | null;
  category: Category;
  taskDate: string | Date;
  filesData: string | null;
  createdAt: string | Date;
  updatedAt: string | Date;
}

export interface User {
  id: number;
  openId: string;
  email: string | null;
  role: string;
  createdAt: string | Date;
}
