import React, { useState, useMemo, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
  SafeAreaView,
  Modal,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import TaskCard from "../components/TaskCard";
import TaskFormScreen from "./TaskFormScreen";
import OfflineBanner from "../components/OfflineBanner";
import { useOfflineTasks } from "../hooks/useOfflineTasks";
import type { Task, Category } from "../types";

interface Props {
  userName?: string | null;
  onLogout: () => void;
}

type FilterCategory = Category | "all";

const FILTERS: { value: FilterCategory; label: string }[] = [
  { value: "all", label: "সব" },
  { value: "learned", label: "শেখা" },
  { value: "completed", label: "সম্পন্ন" },
  { value: "in-progress", label: "চলমান" },
];

export default function DashboardScreen({ userName, onLogout }: Props) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterCategory>("all");
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const {
    tasks,
    isLoading,
    isOnline,
    isSyncing,
    pendingCount,
    refetch,
    deleteTask,
    submitTaskOffline,
    syncPending,
  } = useOfflineTasks();

  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      const matchesSearch =
        task.title.toLowerCase().includes(search.toLowerCase()) ||
        (task.description?.toLowerCase().includes(search.toLowerCase()) ?? false);
      const matchesCategory = filter === "all" || task.category === filter;
      return matchesSearch && matchesCategory;
    });
  }, [tasks, search, filter]);

  const handleDelete = useCallback(
    (id: number) => {
      if (id < 0) {
        Alert.alert("পেন্ডিং কাজ", "এই কাজটি এখনো সার্ভারে সংরক্ষিত হয়নি।");
        return;
      }
      const task = tasks.find((t) => t.id === id);
      Alert.alert(
        "কাজটি মুছে ফেলতে চান?",
        `"${task?.title}" চিরতরে মুছে ফেলা হবে।${!isOnline ? "\n(অফলাইনে — পরে সিঙ্ক হবে)" : ""}`,
        [
          { text: "বাতিল", style: "cancel" },
          {
            text: "মুছে ফেলুন",
            style: "destructive",
            onPress: async () => {
              try {
                await deleteTask(id);
              } catch {
                Alert.alert("ত্রুটি", "মুছতে ব্যর্থ হয়েছে।");
              }
            },
          },
        ]
      );
    },
    [tasks, isOnline, deleteTask]
  );

  const handleEdit = useCallback((task: Task) => {
    if (task.id < 0) {
      Alert.alert("পেন্ডিং কাজ", "এই কাজটি সার্ভারে সংরক্ষিত হওয়ার পর সম্পাদনা করুন।");
      return;
    }
    setEditingTask(task);
    setShowForm(true);
  }, []);

  const handleFormClose = useCallback(() => {
    setShowForm(false);
    setEditingTask(null);
  }, []);

  const handleFormSuccess = useCallback(() => {
    setShowForm(false);
    setEditingTask(null);
    refetch();
  }, [refetch]);

  const handleOfflineSubmit = useCallback(
    (type: "create" | "update", data: Parameters<typeof submitTaskOffline>[0]["data"]) => {
      submitTaskOffline({ type, data });
      setShowForm(false);
      setEditingTask(null);
    },
    [submitTaskOffline]
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const handleLogout = () => {
    Alert.alert("লগআউট", "আপনি কি লগআউট করতে চান?", [
      { text: "না", style: "cancel" },
      { text: "হ্যাঁ", style: "destructive", onPress: onLogout },
    ]);
  };

  const stats = useMemo(
    () => ({
      total: tasks.filter((t) => t.id > 0).length,
      learned: tasks.filter((t) => t.category === "learned" && t.id > 0).length,
      completed: tasks.filter((t) => t.category === "completed" && t.id > 0).length,
      inProgress: tasks.filter((t) => t.category === "in-progress" && t.id > 0).length,
    }),
    [tasks]
  );

  return (
    <SafeAreaView style={styles.safe}>
      <OfflineBanner
        isOnline={isOnline}
        isSyncing={isSyncing}
        pendingCount={pendingCount}
        onSyncPress={syncPending}
      />

      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>আমার কাজ ও দক্ষতা</Text>
          <Text style={styles.headerSub}>
            {userName ? `স্বাগতম, ${userName}` : "আপনার ফ্রিল্যান্সিং যাত্রা"}
          </Text>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutText}>লগআউট</Text>
        </TouchableOpacity>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={[styles.statCard, { backgroundColor: "#f0fdf4" }]}>
          <Text style={[styles.statNum, { color: "#166534" }]}>{stats.learned}</Text>
          <Text style={styles.statLabel}>শেখা</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: "#fef2f2" }]}>
          <Text style={[styles.statNum, { color: "#991b1b" }]}>{stats.completed}</Text>
          <Text style={styles.statLabel}>সম্পন্ন</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: "#fefce8" }]}>
          <Text style={[styles.statNum, { color: "#854d0e" }]}>{stats.inProgress}</Text>
          <Text style={styles.statLabel}>চলমান</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: "#eff6ff" }]}>
          <Text style={[styles.statNum, { color: "#1e40af" }]}>{stats.total}</Text>
          <Text style={styles.statLabel}>মোট</Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="শিরোনাম বা বিবরণ দিয়ে খুঁজুন..."
          placeholderTextColor="#9ca3af"
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch("")}>
            <Text style={styles.clearSearch}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Category Filters */}
      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.value}
            style={[styles.filterBtn, filter === f.value && styles.filterBtnActive]}
            onPress={() => setFilter(f.value)}
          >
            <Text style={[styles.filterText, filter === f.value && styles.filterTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Task List */}
      {isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#dc2626" />
          <Text style={styles.loadingText}>লোড হচ্ছে...</Text>
        </View>
      ) : (
        <FlatList
          data={filteredTasks}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <TaskCard
              task={item}
              onEdit={handleEdit}
              onDelete={handleDelete}
              isPending={item.id < 0}
            />
          )}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyIcon}>📭</Text>
              <Text style={styles.emptyText}>
                {search || filter !== "all" ? "কোনো কাজ পাওয়া যায়নি" : "এখনো কোনো কাজ যোগ করা হয়নি"}
              </Text>
              {!search && filter === "all" && (
                <Text style={styles.emptyHint}>নিচের + বাটন দিয়ে নতুন কাজ যোগ করুন</Text>
              )}
            </View>
          }
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#dc2626"
              enabled={isOnline}
            />
          }
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Add Button */}
      <TouchableOpacity style={styles.fab} onPress={() => setShowForm(true)}>
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>

      {/* Task Form Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <TaskFormScreen
          task={editingTask}
          onClose={handleFormClose}
          onSuccess={handleFormSuccess}
          isOnline={isOnline}
          onOfflineSubmit={handleOfflineSubmit}
        />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f9fafb" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  headerTitle: { fontSize: 18, fontWeight: "800", color: "#111827" },
  headerSub: { fontSize: 12, color: "#6b7280", marginTop: 2 },
  logoutBtn: {
    backgroundColor: "#fef2f2",
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#fecaca",
  },
  logoutText: { color: "#dc2626", fontSize: 13, fontWeight: "600" },
  statsRow: {
    flexDirection: "row",
    paddingHorizontal: 12,
    paddingVertical: 12,
    gap: 8,
    backgroundColor: "#fff",
  },
  statCard: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: "center",
  },
  statNum: { fontSize: 20, fontWeight: "800" },
  statLabel: { fontSize: 11, color: "#6b7280", marginTop: 2 },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    margin: 12,
    backgroundColor: "#fff",
    borderRadius: 12,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  searchIcon: { fontSize: 14, marginRight: 8 },
  searchInput: {
    flex: 1,
    paddingVertical: 11,
    fontSize: 14,
    color: "#111827",
  },
  clearSearch: { color: "#9ca3af", fontSize: 16, paddingLeft: 8 },
  filterRow: {
    flexDirection: "row",
    paddingHorizontal: 12,
    gap: 8,
    marginBottom: 4,
  },
  filterBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#e5e7eb",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  filterBtnActive: { borderColor: "#dc2626", backgroundColor: "#fef2f2" },
  filterText: { fontSize: 12, fontWeight: "600", color: "#6b7280" },
  filterTextActive: { color: "#dc2626" },
  listContent: { padding: 12, paddingBottom: 100 },
  center: { flex: 1, justifyContent: "center", alignItems: "center", gap: 12 },
  loadingText: { color: "#9ca3af", fontSize: 14 },
  emptyContainer: { alignItems: "center", paddingTop: 60, gap: 8 },
  emptyIcon: { fontSize: 48 },
  emptyText: { fontSize: 16, color: "#6b7280", fontWeight: "600" },
  emptyHint: { fontSize: 13, color: "#9ca3af" },
  fab: {
    position: "absolute",
    bottom: 24,
    right: 24,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#dc2626",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#dc2626",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  fabText: { color: "#fff", fontSize: 32, fontWeight: "300", lineHeight: 36 },
});
