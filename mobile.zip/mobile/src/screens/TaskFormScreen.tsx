import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  SafeAreaView,
  ActivityIndicator,
} from "react-native";
import { trpc } from "../api/client";
import { format } from "date-fns";
import type { Task, Category } from "../types";

interface Props {
  task?: Task | null;
  onClose: () => void;
  onSuccess: () => void;
  isOnline?: boolean;
  onOfflineSubmit?: (
    type: "create" | "update",
    data: {
      id?: number;
      title: string;
      description?: string;
      category: Category;
      taskDate: string;
    }
  ) => void;
}

const CATEGORIES: { value: Category; label: string }[] = [
  { value: "in-progress", label: "চলমান" },
  { value: "learned", label: "শেখা" },
  { value: "completed", label: "সম্পন্ন" },
];

export default function TaskFormScreen({
  task,
  onClose,
  onSuccess,
  isOnline = true,
  onOfflineSubmit,
}: Props) {
  const [title, setTitle] = useState(task?.title ?? "");
  const [description, setDescription] = useState(task?.description ?? "");
  const [category, setCategory] = useState<Category>(task?.category ?? "in-progress");
  const [taskDate, setTaskDate] = useState(
    task ? format(new Date(task.taskDate), "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd")
  );
  const [isLoading, setIsLoading] = useState(false);

  const createMutation = trpc.tasks.create.useMutation();
  const updateMutation = trpc.tasks.update.useMutation();

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert("ত্রুটি", "শিরোনাম প্রয়োজন");
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(taskDate)) {
      Alert.alert("ত্রুটি", "তারিখ সঠিক ফরম্যাটে দিন (YYYY-MM-DD)");
      return;
    }

    const submitData = {
      id: task?.id,
      title: title.trim(),
      description: description.trim() || undefined,
      category,
      taskDate,
    };

    if (!isOnline) {
      if (onOfflineSubmit) {
        Alert.alert(
          "অফলাইন মোড",
          "ইন্টারনেট সংযোগ নেই। কাজটি স্থানীয়ভাবে সংরক্ষিত হবে এবং অনলাইন হলে স্বয়ংক্রিয়ভাবে সিঙ্ক হবে।",
          [
            { text: "বাতিল", style: "cancel" },
            {
              text: "সংরক্ষণ করুন",
              onPress: () => {
                onOfflineSubmit(task ? "update" : "create", submitData);
              },
            },
          ]
        );
      } else {
        Alert.alert("অফলাইন", "এই মুহূর্তে কাজ যোগ করা সম্ভব নয়। ইন্টারনেট সংযোগ দিন।");
      }
      return;
    }

    setIsLoading(true);
    try {
      if (task) {
        await updateMutation.mutateAsync({
          id: task.id,
          title: title.trim(),
          description: description.trim() || undefined,
          category,
          taskDate: new Date(taskDate),
        });
        Alert.alert("সফল!", "কাজ আপডেট হয়েছে", [{ text: "ঠিক আছে", onPress: onSuccess }]);
      } else {
        await createMutation.mutateAsync({
          title: title.trim(),
          description: description.trim() || undefined,
          category,
          taskDate: new Date(taskDate),
        });
        Alert.alert("সফল!", "নতুন কাজ যোগ হয়েছে", [{ text: "ঠিক আছে", onPress: onSuccess }]);
      }
    } catch {
      Alert.alert("ত্রুটি", "কিছু সমস্যা হয়েছে। আবার চেষ্টা করুন।");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.cancelBtn}>
          <Text style={styles.cancelText}>বাতিল</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{task ? "কাজ সম্পাদনা" : "নতুন কাজ"}</Text>
        <View style={{ width: 60 }} />
      </View>

      {!isOnline && (
        <View style={styles.offlineNote}>
          <Text style={styles.offlineNoteText}>📵 অফলাইন — সংরক্ষিত হলে পরে সিঙ্ক হবে</Text>
        </View>
      )}

      <ScrollView style={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.form}>
          <View style={styles.field}>
            <Text style={styles.label}>শিরোনাম *</Text>
            <TextInput
              style={styles.input}
              placeholder="কাজের শিরোনাম"
              placeholderTextColor="#9ca3af"
              value={title}
              onChangeText={setTitle}
              returnKeyType="next"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>বিবরণ</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="কাজের বিস্তারিত বিবরণ"
              placeholderTextColor="#9ca3af"
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>ক্যাটাগরি</Text>
            <View style={styles.categoryRow}>
              {CATEGORIES.map((cat) => (
                <TouchableOpacity
                  key={cat.value}
                  style={[
                    styles.categoryBtn,
                    category === cat.value && styles.categoryBtnActive,
                  ]}
                  onPress={() => setCategory(cat.value)}
                >
                  <Text
                    style={[
                      styles.categoryBtnText,
                      category === cat.value && styles.categoryBtnTextActive,
                    ]}
                  >
                    {cat.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>তারিখ (YYYY-MM-DD)</Text>
            <TextInput
              style={styles.input}
              placeholder="2026-06-27"
              placeholderTextColor="#9ca3af"
              value={taskDate}
              onChangeText={setTaskDate}
              keyboardType="numbers-and-punctuation"
            />
          </View>

          <TouchableOpacity
            style={[styles.submitBtn, isLoading && styles.submitBtnDisabled]}
            onPress={handleSubmit}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.submitBtnText}>
                {!isOnline ? "📵 অফলাইনে সংরক্ষণ করুন" : task ? "আপডেট করুন" : "যোগ করুন"}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  cancelBtn: { width: 60 },
  cancelText: { color: "#dc2626", fontSize: 15, fontWeight: "500" },
  headerTitle: { fontSize: 17, fontWeight: "700", color: "#111827" },
  offlineNote: {
    backgroundColor: "#fef2f2",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#fecaca",
  },
  offlineNoteText: { color: "#991b1b", fontSize: 13, fontWeight: "500" },
  scroll: { flex: 1 },
  form: { padding: 20, gap: 20 },
  field: { gap: 8 },
  label: { fontSize: 14, fontWeight: "600", color: "#374151" },
  input: {
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: "#111827",
    backgroundColor: "#fafafa",
  },
  textArea: { height: 100, paddingTop: 12 },
  categoryRow: { flexDirection: "row", gap: 10 },
  categoryBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: "#e5e7eb",
    alignItems: "center",
    backgroundColor: "#f9fafb",
  },
  categoryBtnActive: { borderColor: "#dc2626", backgroundColor: "#fef2f2" },
  categoryBtnText: { fontSize: 13, fontWeight: "600", color: "#6b7280" },
  categoryBtnTextActive: { color: "#dc2626" },
  submitBtn: {
    backgroundColor: "#dc2626",
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: "center",
    marginTop: 8,
  },
  submitBtnDisabled: { backgroundColor: "#f87171" },
  submitBtnText: { color: "#fff", fontSize: 16, fontWeight: "700" },
});
