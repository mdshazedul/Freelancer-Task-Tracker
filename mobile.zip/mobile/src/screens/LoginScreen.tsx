import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  SafeAreaView,
  ActivityIndicator,
  Linking,
  ScrollView,
} from "react-native";

interface Props {
  baseUrl: string;
  onLoginSuccess: () => void;
}

export default function LoginScreen({ baseUrl, onLoginSuccess }: Props) {
  const [isLoading, setIsLoading] = useState(false);

  const handleOpenBrowser = async () => {
    setIsLoading(true);
    try {
      const loginUrl = `${baseUrl}/api/oauth/login`;
      await Linking.openURL(loginUrl);
      Alert.alert(
        "ব্রাউজারে লগইন করুন",
        "ব্রাউজারে লগইন সম্পন্ন হলে এখানে ফিরে আসুন এবং 'লগইন যাচাই করুন' বাটনে চাপুন।",
        [{ text: "লগইন যাচাই করুন", onPress: onLoginSuccess }]
      );
    } catch (error) {
      Alert.alert("ত্রুটি", "ব্রাউজার খুলতে ব্যর্থ।");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.logoContainer}>
          <View style={styles.logoBadge} />
          <Text style={styles.logoText}>কাজ ট্র্যাকার</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.title}>স্বাগতম!</Text>
          <Text style={styles.subtitle}>
            আপনার ফ্রিল্যান্সিং যাত্রা ট্র্যাক করতে লগইন করুন
          </Text>

          <TouchableOpacity
            style={[styles.loginBtn, isLoading && styles.loginBtnDisabled]}
            onPress={handleOpenBrowser}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.loginBtnText}>🔐 লগইন করুন</Text>
            )}
          </TouchableOpacity>

          <Text style={styles.note}>
            লগইন করলে আপনার অ্যাকাউন্টের সাথে সুরক্ষিতভাবে সংযুক্ত হবেন।
          </Text>
        </View>

        <View style={styles.features}>
          {[
            { icon: "✅", text: "কাজ ট্র্যাক করুন" },
            { icon: "🔒", text: "সম্পূর্ণ ব্যক্তিগত" },
            { icon: "📊", text: "অগ্রগতি দেখুন" },
          ].map((f, i) => (
            <View key={i} style={styles.featureItem}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={styles.featureText}>{f.text}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.footer}>© 2026 কাজ ট্র্যাকার — সজীবের জন্য তৈরি</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fef2f2" },
  container: {
    flexGrow: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
    paddingVertical: 48,
    gap: 24,
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 8,
  },
  logoBadge: {
    width: 36,
    height: 24,
    borderRadius: 6,
    backgroundColor: "#dc2626",
  },
  logoText: { fontSize: 24, fontWeight: "800", color: "#111827" },
  card: {
    backgroundColor: "#fff",
    borderRadius: 24,
    padding: 28,
    width: "100%",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 16,
    elevation: 4,
    gap: 16,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    color: "#111827",
  },
  subtitle: {
    fontSize: 15,
    color: "#6b7280",
    textAlign: "center",
    lineHeight: 22,
  },
  loginBtn: {
    backgroundColor: "#dc2626",
    paddingHorizontal: 40,
    paddingVertical: 16,
    borderRadius: 14,
    width: "100%",
    alignItems: "center",
    marginTop: 8,
  },
  loginBtnDisabled: { backgroundColor: "#f87171" },
  loginBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  note: {
    fontSize: 12,
    color: "#9ca3af",
    textAlign: "center",
    lineHeight: 18,
  },
  features: {
    flexDirection: "row",
    gap: 16,
    justifyContent: "center",
  },
  featureItem: { alignItems: "center", gap: 6 },
  featureIcon: { fontSize: 24 },
  featureText: { fontSize: 12, color: "#6b7280", fontWeight: "500" },
  footer: { fontSize: 11, color: "#9ca3af" },
});
