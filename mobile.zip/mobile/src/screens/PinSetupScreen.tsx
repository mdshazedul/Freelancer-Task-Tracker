import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Alert,
  ActivityIndicator,
  SafeAreaView,
} from "react-native";
import PinPad from "../components/PinPad";
import { useDevicePin } from "../hooks/useDevicePin";
import { trpc } from "../api/client";

interface Props {
  onComplete: () => void;
}

export default function PinSetupScreen({ onComplete }: Props) {
  const [step, setStep] = useState<"enter" | "confirm">("enter");
  const [firstPin, setFirstPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { deviceId, storePin, setPinSetup } = useDevicePin();
  const setupMutation = trpc.devicePin.setup.useMutation();

  const handleFirstPin = (pin: string) => {
    setFirstPin(pin);
    setStep("confirm");
  };

  const handleConfirmPin = async (pin: string) => {
    if (pin !== firstPin) {
      Alert.alert("ত্রুটি", "পিন কোড মিলছে না। আবার চেষ্টা করুন।");
      setStep("enter");
      setFirstPin("");
      return;
    }

    setIsLoading(true);
    try {
      await setupMutation.mutateAsync({ pin, deviceId });
      await storePin(pin);
      await setPinSetup(true);
      Alert.alert("সফল!", "পিন কোড সেট হয়েছে।", [
        { text: "ঠিক আছে", onPress: onComplete },
      ]);
    } catch (error) {
      Alert.alert("ত্রুটি", "পিন সেট করতে ব্যর্থ হয়েছে।");
      setStep("enter");
      setFirstPin("");
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator size="large" color="#dc2626" />
        <Text style={styles.loadingText}>সেট হচ্ছে...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.iconContainer}>
        <Text style={styles.icon}>🔒</Text>
      </View>

      {step === "enter" ? (
        <PinPad
          onComplete={handleFirstPin}
          title="পিন কোড তৈরি করুন"
          subtitle="৪-৬ অঙ্কের একটি পিন কোড দিন"
        />
      ) : (
        <PinPad
          onComplete={handleConfirmPin}
          title="পিন কোড নিশ্চিত করুন"
          subtitle="আবার একই পিন কোড দিন"
        />
      )}

      <Text style={styles.note}>এই পিন কোড শুধুমাত্র এই ডিভাইসে কাজ করবে</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fef2f2",
    alignItems: "center",
    justifyContent: "center",
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fef2f2",
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  icon: {
    fontSize: 36,
  },
  loadingText: {
    marginTop: 12,
    color: "#6b7280",
    fontSize: 16,
  },
  note: {
    fontSize: 12,
    color: "#9ca3af",
    marginTop: 24,
    textAlign: "center",
    paddingHorizontal: 32,
  },
});
