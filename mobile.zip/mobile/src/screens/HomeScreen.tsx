import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  Linking,
} from "react-native";

interface Props {
  onLogin: () => void;
  baseUrl: string;
}

const features = [
  { icon: "✅", title: "সহজ যোগ করুন", desc: "কাজের নাম, বিবরণ ও ক্যাটাগরি দিয়ে সহজেই এন্ট্রি যোগ করুন।" },
  { icon: "🔍", title: "তাৎক্ষণিক সার্চ", desc: "শিরোনাম বা বিবরণ দিয়ে রিয়েল-টাইমে কাজ খুঁজুন।" },
  { icon: "⚡", title: "স্মার্ট ফিল্টার", desc: "শেখা, সম্পন্ন বা চলমান — যেকোনো ক্যাটাগরি দিয়ে ফিল্টার করুন।" },
  { icon: "✏️", title: "সম্পাদনা করুন", desc: "যেকোনো সময় কাজের তথ্য আপডেট করুন।" },
  { icon: "🗑", title: "মুছে ফেলুন", desc: "প্রয়োজন অনুযায়ী পুরানো এন্ট্রি সরিয়ে ফেলুন।" },
  { icon: "🔒", title: "সম্পূর্ণ ব্যক্তিগত", desc: "শুধুমাত্র আপনি আপনার ডেটা অ্যাক্সেস করতে পারবেন।" },
];

export default function HomeScreen({ onLogin, baseUrl }: Props) {
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Nav */}
        <View style={styles.nav}>
          <View style={styles.logoRow}>
            <View style={styles.logoBadge} />
            <Text style={styles.logoText}>কাজ ট্র্যাকার</Text>
          </View>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.heroTitle}>আপনার ফ্রিল্যান্সিং যাত্রা ট্র্যাক করুন</Text>
          <Text style={styles.heroSubtitle}>
            প্রতিটি কাজ, প্রতিটি দক্ষতা, প্রতিটি অর্জন একটি জায়গায়। এলিগ্যান্ট, সহজ এবং শক্তিশালী।
          </Text>
          <TouchableOpacity style={styles.loginBtn} onPress={onLogin}>
            <Text style={styles.loginBtnText}>এখনই শুরু করুন →</Text>
          </TouchableOpacity>
        </View>

        {/* Features */}
        <View style={styles.features}>
          {features.map((f, i) => (
            <View key={i} style={styles.featureCard}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={styles.featureTitle}>{f.title}</Text>
              <Text style={styles.featureDesc}>{f.desc}</Text>
            </View>
          ))}
        </View>

        {/* CTA */}
        <View style={styles.cta}>
          <Text style={styles.ctaTitle}>আজই শুরু করুন</Text>
          <Text style={styles.ctaSubtitle}>
            আপনার ফ্রিল্যান্সিং যাত্রা ট্র্যাক করা এখন আরও সহজ।
          </Text>
          <TouchableOpacity style={styles.ctaBtn} onPress={onLogin}>
            <Text style={styles.ctaBtnText}>লগইন করুন</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>© 2026 কাজ ট্র্যাকার — সজীবের জন্য তৈরি</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff" },
  scroll: { flex: 1 },
  nav: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  logoBadge: {
    width: 28,
    height: 18,
    borderRadius: 4,
    backgroundColor: "#dc2626",
  },
  logoText: { fontSize: 18, fontWeight: "700", color: "#111827" },
  hero: {
    alignItems: "center",
    paddingHorizontal: 24,
    paddingVertical: 48,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: "800",
    color: "#111827",
    textAlign: "center",
    lineHeight: 38,
    marginBottom: 16,
  },
  heroSubtitle: {
    fontSize: 15,
    color: "#6b7280",
    textAlign: "center",
    lineHeight: 24,
    marginBottom: 32,
  },
  loginBtn: {
    backgroundColor: "#dc2626",
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 14,
  },
  loginBtnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "700",
  },
  features: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 16,
    gap: 12,
    justifyContent: "space-between",
  },
  featureCard: {
    width: "47%",
    backgroundColor: "#f9fafb",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#f3f4f6",
  },
  featureIcon: { fontSize: 24, marginBottom: 8 },
  featureTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 6,
  },
  featureDesc: {
    fontSize: 12,
    color: "#6b7280",
    lineHeight: 18,
  },
  cta: {
    backgroundColor: "#dc2626",
    margin: 20,
    borderRadius: 20,
    padding: 28,
    alignItems: "center",
    marginTop: 32,
  },
  ctaTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#fff",
    marginBottom: 8,
  },
  ctaSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.85)",
    textAlign: "center",
    marginBottom: 20,
    lineHeight: 22,
  },
  ctaBtn: {
    backgroundColor: "#fff",
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 12,
  },
  ctaBtnText: {
    color: "#dc2626",
    fontWeight: "700",
    fontSize: 15,
  },
  footer: {
    paddingVertical: 20,
    alignItems: "center",
    borderTopWidth: 1,
    borderTopColor: "#f3f4f6",
    marginTop: 8,
  },
  footerText: { fontSize: 12, color: "#9ca3af" },
});
