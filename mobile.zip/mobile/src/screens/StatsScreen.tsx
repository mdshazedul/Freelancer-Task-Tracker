import React, { useMemo } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
} from "react-native";
import OfflineBanner from "../components/OfflineBanner";
import { useOfflineTasks } from "../hooks/useOfflineTasks";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachMonthOfInterval,
  subMonths,
  isWithinInterval,
  isToday,
  subDays,
} from "date-fns";
import type { Task, Category } from "../types";

const CAT_COLORS: Record<Category, string> = {
  learned: "#22c55e",
  completed: "#ef4444",
  "in-progress": "#eab308",
};
const CAT_LABELS: Record<Category, string> = {
  learned: "শেখা",
  completed: "সম্পন্ন",
  "in-progress": "চলমান",
};
const CAT_BG: Record<Category, string> = {
  learned: "#f0fdf4",
  completed: "#fef2f2",
  "in-progress": "#fefce8",
};

function useStats(tasks: Task[]) {
  return useMemo(() => {
    const total = tasks.length;
    const byCat = {
      learned: tasks.filter((t) => t.category === "learned").length,
      completed: tasks.filter((t) => t.category === "completed").length,
      "in-progress": tasks.filter((t) => t.category === "in-progress").length,
    };

    // Last 6 months data
    const now = new Date();
    const months = eachMonthOfInterval({
      start: subMonths(now, 5),
      end: now,
    });
    const monthlyData = months.map((month) => {
      const start = startOfMonth(month);
      const end = endOfMonth(month);
      const count = tasks.filter((t) => {
        const d = new Date(t.taskDate);
        return isWithinInterval(d, { start, end });
      }).length;
      return { label: format(month, "MMM"), count };
    });
    const maxMonthly = Math.max(...monthlyData.map((m) => m.count), 1);

    // Last 7 days streak data
    const last7 = Array.from({ length: 7 }, (_, i) => {
      const day = subDays(now, 6 - i);
      const count = tasks.filter((t) => {
        const d = new Date(t.taskDate);
        return (
          d.getFullYear() === day.getFullYear() &&
          d.getMonth() === day.getMonth() &&
          d.getDate() === day.getDate()
        );
      }).length;
      return { label: format(day, "EEE"), count, date: day };
    });

    // Current streak (consecutive days with at least 1 task)
    let streak = 0;
    for (let i = 0; i <= 30; i++) {
      const day = subDays(now, i);
      const hasTask = tasks.some((t) => {
        const d = new Date(t.taskDate);
        return (
          d.getFullYear() === day.getFullYear() &&
          d.getMonth() === day.getMonth() &&
          d.getDate() === day.getDate()
        );
      });
      if (hasTask) streak++;
      else break;
    }

    // Most productive month
    const bestMonth = monthlyData.reduce(
      (best, m) => (m.count > best.count ? m : best),
      monthlyData[0]
    );

    // This month vs last month
    const thisMonthCount = monthlyData[monthlyData.length - 1].count;
    const lastMonthCount = monthlyData[monthlyData.length - 2]?.count ?? 0;
    const monthGrowth =
      lastMonthCount === 0
        ? 100
        : Math.round(((thisMonthCount - lastMonthCount) / lastMonthCount) * 100);

    return {
      total,
      byCat,
      monthlyData,
      maxMonthly,
      last7,
      streak,
      bestMonth,
      thisMonthCount,
      lastMonthCount,
      monthGrowth,
    };
  }, [tasks]);
}

// Custom donut chart using View borders
function DonutChart({
  data,
  total,
}: {
  data: { value: number; color: string; label: string }[];
  total: number;
}) {
  const SIZE = 140;
  const STROKE = 20;

  if (total === 0) {
    return (
      <View style={[donutStyles.container, { width: SIZE, height: SIZE }]}>
        <View
          style={[
            donutStyles.outer,
            { width: SIZE, height: SIZE, borderRadius: SIZE / 2, borderColor: "#e5e7eb" },
          ]}
        />
        <View style={donutStyles.center}>
          <Text style={donutStyles.centerNum}>0</Text>
          <Text style={donutStyles.centerLabel}>মোট কাজ</Text>
        </View>
      </View>
    );
  }

  // Build stacked ring segments with solid border trick
  const segments = data.filter((d) => d.value > 0);
  const pct = segments.map((s) => s.value / total);

  // We approximate donut with colored bars instead of real SVG
  return (
    <View style={donutStyles.wrapper}>
      <View style={[donutStyles.ring, { width: SIZE, height: SIZE, borderRadius: SIZE / 2 }]}>
        <View style={donutStyles.center}>
          <Text style={donutStyles.centerNum}>{total}</Text>
          <Text style={donutStyles.centerLabel}>মোট কাজ</Text>
        </View>
      </View>
      {/* Stacked horizontal bar as alternative */}
      <View style={donutStyles.barStack}>
        {segments.map((s, i) => (
          <View
            key={i}
            style={[
              donutStyles.barSegment,
              {
                flex: s.value,
                backgroundColor: s.color,
                borderTopLeftRadius: i === 0 ? 6 : 0,
                borderBottomLeftRadius: i === 0 ? 6 : 0,
                borderTopRightRadius: i === segments.length - 1 ? 6 : 0,
                borderBottomRightRadius: i === segments.length - 1 ? 6 : 0,
              },
            ]}
          />
        ))}
      </View>
    </View>
  );
}

const donutStyles = StyleSheet.create({
  wrapper: { alignItems: "center", gap: 12 },
  container: { alignItems: "center", justifyContent: "center" },
  outer: {
    position: "absolute",
    borderWidth: 16,
  },
  ring: {
    backgroundColor: "#f9fafb",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 16,
    borderColor: "#e5e7eb",
  },
  center: { alignItems: "center" },
  centerNum: { fontSize: 28, fontWeight: "800", color: "#111827" },
  centerLabel: { fontSize: 11, color: "#9ca3af", marginTop: 2 },
  barStack: {
    flexDirection: "row",
    height: 12,
    width: 200,
    borderRadius: 6,
    overflow: "hidden",
    backgroundColor: "#e5e7eb",
  },
  barSegment: { height: 12 },
});

export default function StatsScreen() {
  const { tasks, isLoading, isOnline, isSyncing, pendingCount } = useOfflineTasks();
  const s = useStats(tasks.filter((t) => (t.id as number) > 0));

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#dc2626" />
          <Text style={styles.loadingText}>লোড হচ্ছে...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const catData = (["learned", "completed", "in-progress"] as Category[]).map(
    (c) => ({
      value: s.byCat[c],
      color: CAT_COLORS[c],
      label: CAT_LABELS[c],
    })
  );

  return (
    <SafeAreaView style={styles.safe}>
      <OfflineBanner
        isOnline={isOnline}
        isSyncing={isSyncing}
        pendingCount={pendingCount}
      />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>পরিসংখ্যান</Text>
        <Text style={styles.headerSub}>আপনার অগ্রগতির বিশ্লেষণ</Text>
      </View>

      <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* ── Summary Cards ── */}
        <View style={styles.section}>
          <View style={styles.statGrid}>
            <View style={[styles.statCard, { backgroundColor: "#eff6ff" }]}>
              <Text style={[styles.statNum, { color: "#1d4ed8" }]}>{s.total}</Text>
              <Text style={styles.statLabel}>মোট কাজ</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: "#f0fdf4" }]}>
              <Text style={[styles.statNum, { color: "#166534" }]}>{s.byCat.learned}</Text>
              <Text style={styles.statLabel}>শেখা হয়েছে</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: "#fef2f2" }]}>
              <Text style={[styles.statNum, { color: "#991b1b" }]}>{s.byCat.completed}</Text>
              <Text style={styles.statLabel}>সম্পন্ন</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: "#fefce8" }]}>
              <Text style={[styles.statNum, { color: "#854d0e" }]}>{s.byCat["in-progress"]}</Text>
              <Text style={styles.statLabel}>চলমান</Text>
            </View>
          </View>
        </View>

        {/* ── Streak ── */}
        <View style={styles.section}>
          <View style={styles.streakCard}>
            <View>
              <Text style={styles.streakNum}>🔥 {s.streak}</Text>
              <Text style={styles.streakLabel}>দিনের ধারাবাহিকতা</Text>
            </View>
            <View style={styles.streakRight}>
              <Text style={styles.streakMonth}>{s.thisMonthCount}</Text>
              <Text style={styles.streakMonthLabel}>এই মাসে</Text>
              {s.monthGrowth !== 0 && (
                <Text
                  style={[
                    styles.streakGrowth,
                    { color: s.monthGrowth > 0 ? "#22c55e" : "#ef4444" },
                  ]}
                >
                  {s.monthGrowth > 0 ? "▲" : "▼"} {Math.abs(s.monthGrowth)}%
                </Text>
              )}
            </View>
          </View>
        </View>

        {/* ── Category Breakdown ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ক্যাটাগরি বিশ্লেষণ</Text>
          <View style={styles.card}>
            <DonutChart data={catData} total={s.total} />
            <View style={styles.legendList}>
              {(["learned", "completed", "in-progress"] as Category[]).map((cat) => {
                const count = s.byCat[cat];
                const pct = s.total > 0 ? Math.round((count / s.total) * 100) : 0;
                return (
                  <View key={cat} style={styles.legendRow}>
                    <View style={[styles.legendDot, { backgroundColor: CAT_COLORS[cat] }]} />
                    <Text style={styles.legendLabel}>{CAT_LABELS[cat]}</Text>
                    <View style={styles.legendBarWrap}>
                      <View
                        style={[
                          styles.legendBar,
                          {
                            width: `${pct}%` as any,
                            backgroundColor: CAT_COLORS[cat],
                            opacity: 0.25,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.legendCount}>{count}</Text>
                    <Text style={styles.legendPct}>{pct}%</Text>
                  </View>
                );
              })}
            </View>
          </View>
        </View>

        {/* ── Monthly Bar Chart ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>মাসিক অগ্রগতি (শেষ ৬ মাস)</Text>
          <View style={styles.card}>
            <View style={styles.barChart}>
              {s.monthlyData.map((m, i) => {
                const heightPct = s.maxMonthly > 0 ? m.count / s.maxMonthly : 0;
                const barH = Math.max(heightPct * 100, m.count > 0 ? 8 : 4);
                const isCurrentMonth = i === s.monthlyData.length - 1;
                return (
                  <View key={i} style={styles.barCol}>
                    {m.count > 0 && (
                      <Text style={styles.barValue}>{m.count}</Text>
                    )}
                    <View style={styles.barWrapper}>
                      <View
                        style={[
                          styles.bar,
                          {
                            height: barH,
                            backgroundColor: isCurrentMonth ? "#dc2626" : "#fca5a5",
                          },
                        ]}
                      />
                    </View>
                    <Text
                      style={[
                        styles.barLabel,
                        isCurrentMonth && styles.barLabelActive,
                      ]}
                    >
                      {m.label}
                    </Text>
                  </View>
                );
              })}
            </View>
            {s.bestMonth && s.bestMonth.count > 0 && (
              <Text style={styles.chartNote}>
                🏆 সেরা মাস: {s.bestMonth.label} ({s.bestMonth.count}টি কাজ)
              </Text>
            )}
          </View>
        </View>

        {/* ── Last 7 Days ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>সাম্প্রতিক ৭ দিন</Text>
          <View style={styles.card}>
            <View style={styles.weekRow}>
              {s.last7.map((d, i) => {
                const isActive = d.count > 0;
                const isTodayDay = isToday(d.date);
                return (
                  <View key={i} style={styles.dayCol}>
                    <View
                      style={[
                        styles.dayCircle,
                        isActive && styles.dayCircleActive,
                        isTodayDay && styles.dayCircleToday,
                      ]}
                    >
                      <Text
                        style={[
                          styles.dayCount,
                          isActive && styles.dayCountActive,
                        ]}
                      >
                        {d.count > 0 ? d.count : "·"}
                      </Text>
                    </View>
                    <Text
                      style={[styles.dayLabel, isTodayDay && styles.dayLabelToday]}
                    >
                      {d.label}
                    </Text>
                  </View>
                );
              })}
            </View>
            <View style={styles.weekLegend}>
              <View style={styles.legendDotSmall} />
              <Text style={styles.weekLegendText}>কাজ করা হয়েছে</Text>
              <View style={[styles.legendDotSmall, { backgroundColor: "#e5e7eb" }]} />
              <Text style={styles.weekLegendText}>কাজ নেই</Text>
            </View>
          </View>
        </View>

        {/* ── Insights ── */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>মূল তথ্য</Text>
          <View style={styles.insightsList}>
            <View style={styles.insightItem}>
              <Text style={styles.insightIcon}>📚</Text>
              <View style={styles.insightText}>
                <Text style={styles.insightTitle}>শেখার হার</Text>
                <Text style={styles.insightValue}>
                  {s.total > 0
                    ? `${Math.round((s.byCat.learned / s.total) * 100)}% কাজ "শেখা" ক্যাটাগরিতে`
                    : "এখনো কোনো কাজ নেই"}
                </Text>
              </View>
            </View>
            <View style={styles.insightItem}>
              <Text style={styles.insightIcon}>⚡</Text>
              <View style={styles.insightText}>
                <Text style={styles.insightTitle}>সম্পন্নের হার</Text>
                <Text style={styles.insightValue}>
                  {s.total > 0
                    ? `${Math.round(((s.byCat.learned + s.byCat.completed) / s.total) * 100)}% কাজ সম্পন্ন`
                    : "এখনো কোনো কাজ নেই"}
                </Text>
              </View>
            </View>
            <View style={styles.insightItem}>
              <Text style={styles.insightIcon}>🗓</Text>
              <View style={styles.insightText}>
                <Text style={styles.insightTitle}>গড় কাজ</Text>
                <Text style={styles.insightValue}>
                  {s.monthlyData.length > 0
                    ? `মাসে গড়ে ${Math.round(s.total / 6)} টি কাজ`
                    : "ডেটা নেই"}
                </Text>
              </View>
            </View>
            <View style={styles.insightItem}>
              <Text style={styles.insightIcon}>🎯</Text>
              <View style={styles.insightText}>
                <Text style={styles.insightTitle}>চলমান কাজ</Text>
                <Text style={styles.insightValue}>
                  {s.byCat["in-progress"] > 0
                    ? `${s.byCat["in-progress"]}টি কাজ এখনো চলছে`
                    : "সব কাজ সম্পন্ন! 🎉"}
                </Text>
              </View>
            </View>
          </View>
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f9fafb" },
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  loadingText: { marginTop: 12, color: "#6b7280", fontSize: 15 },

  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  headerTitle: { fontSize: 20, fontWeight: "800", color: "#111827" },
  headerSub: { fontSize: 12, color: "#6b7280", marginTop: 2 },

  scroll: { flex: 1 },
  section: { marginTop: 16, paddingHorizontal: 16 },
  sectionTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#374151",
    marginBottom: 10,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },

  card: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 18,
    borderWidth: 1,
    borderColor: "#f3f4f6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    gap: 16,
  },

  // Summary grid
  statGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  statCard: {
    width: "47%",
    borderRadius: 14,
    padding: 14,
    alignItems: "center",
  },
  statNum: { fontSize: 32, fontWeight: "900" },
  statLabel: { fontSize: 12, color: "#6b7280", marginTop: 2, fontWeight: "500" },

  // Streak card
  streakCard: {
    backgroundColor: "#fff",
    borderRadius: 18,
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#f3f4f6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  streakNum: { fontSize: 28, fontWeight: "800", color: "#111827" },
  streakLabel: { fontSize: 13, color: "#6b7280", marginTop: 4 },
  streakRight: { alignItems: "flex-end" },
  streakMonth: { fontSize: 32, fontWeight: "900", color: "#dc2626" },
  streakMonthLabel: { fontSize: 12, color: "#6b7280" },
  streakGrowth: { fontSize: 13, fontWeight: "700", marginTop: 2 },

  // Legend
  legendList: { gap: 10 },
  legendRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendLabel: { fontSize: 13, color: "#374151", width: 60, fontWeight: "500" },
  legendBarWrap: {
    flex: 1,
    height: 8,
    backgroundColor: "#f3f4f6",
    borderRadius: 4,
    overflow: "hidden",
  },
  legendBar: { height: 8, borderRadius: 4 },
  legendCount: { fontSize: 13, fontWeight: "700", color: "#111827", width: 28, textAlign: "right" },
  legendPct: { fontSize: 11, color: "#9ca3af", width: 36, textAlign: "right" },

  // Bar chart
  barChart: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    height: 130,
    gap: 4,
  },
  barCol: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 4,
  },
  barValue: { fontSize: 10, fontWeight: "700", color: "#374151" },
  barWrapper: {
    width: "100%",
    alignItems: "center",
    justifyContent: "flex-end",
    height: 100,
  },
  bar: {
    width: "100%",
    borderRadius: 6,
    minHeight: 4,
  },
  barLabel: { fontSize: 10, color: "#9ca3af", fontWeight: "500" },
  barLabelActive: { color: "#dc2626", fontWeight: "700" },
  chartNote: { fontSize: 12, color: "#6b7280", textAlign: "center" },

  // Last 7 days
  weekRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 4,
  },
  dayCol: { flex: 1, alignItems: "center", gap: 6 },
  dayCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "#f3f4f6",
    alignItems: "center",
    justifyContent: "center",
  },
  dayCircleActive: { backgroundColor: "#dc2626" },
  dayCircleToday: {
    borderWidth: 2,
    borderColor: "#dc2626",
    backgroundColor: "#fef2f2",
  },
  dayCount: { fontSize: 12, fontWeight: "700", color: "#9ca3af" },
  dayCountActive: { color: "#fff" },
  dayLabel: { fontSize: 10, color: "#9ca3af", fontWeight: "500" },
  dayLabelToday: { color: "#dc2626", fontWeight: "700" },
  weekLegend: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  legendDotSmall: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#dc2626",
  },
  weekLegendText: { fontSize: 11, color: "#9ca3af" },

  // Insights
  insightsList: {
    backgroundColor: "#fff",
    borderRadius: 18,
    borderWidth: 1,
    borderColor: "#f3f4f6",
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  insightItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#f9fafb",
  },
  insightIcon: { fontSize: 24 },
  insightText: { flex: 1 },
  insightTitle: { fontSize: 13, fontWeight: "700", color: "#374151" },
  insightValue: { fontSize: 13, color: "#6b7280", marginTop: 2 },
});
