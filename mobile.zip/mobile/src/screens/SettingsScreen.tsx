import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  Alert,
  ScrollView,
} from "react-native";
import { useDevicePin } from "../hooks/useDevicePin";

interface Props {
  user?: { email: string | null; openId: string } | null;
  onLogout: () => void;
  onResetPin: () => void;
}

export default function SettingsScreen({ user, onLogout, onResetPin }: Props) {
  const { clearPin } = useDevicePin();

  const handleResetPin = () => {
    Alert.alert(
      "পিন রিসেট করুন",
      "আপনার বর্তমান পিন কোড মুছে যাবে এবং নতুন পিন সেট করতে হবে।",
      [
        { text: "বাতিল", style: "cancel" },
        {
          text: "রিসেট করুন",
          style: "destructive",
          onPress: async () => {
            await clearPin();
            onResetPin();
          },
        },
      ]
    );
  };

  const handleLogout = () => {
    Alert.alert("লগআউট", "আপনি কি নিশ্চিতভাবে লগআউট করতে চান?", [
      { text: "না", style: "cancel" },
      { text: "হ্যাঁ, লগআউট", style: "destructive", onPress: onLogout },
    ]);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>সেটিংস</Text>
      </View>
      <ScrollView style={styles.scroll}>
        {/* Profile */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>প্রোফাইল</Text>
          <View style={styles.profileCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {user?.email?.[0]?.toUpperCase() ?? "S"}
              </Text>
            </View>
            <View>
              <Text style={styles.email}>{user?.email ?? "সজীব"}</Text>
              <Text style={styles.role}>অ্যাপের মালিক</Text>
            </View>
          </View>
        </View>

        {/* Security */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>নিরাপত্তা</Text>
          <TouchableOpacity style={styles.menuItem} onPress={handleResetPin}>
            <Text style={styles.menuIcon}>🔑</Text>
            <View style={styles.menuText}>
              <Text style={styles.menuTitle}>পিন কোড পরিবর্তন করুন</Text>
              <Text style={styles.menuSub}>নতুন পিন কোড সেট করুন</Text>
            </View>
            <Text style={styles.menuArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>অ্যাপ সম্পর্কে</Text>
          <View style={styles.menuItem}>
            <Text style={styles.menuIcon}>📱</Text>
            <View style={styles.menuText}>
              <Text style={styles.menuTitle}>কাজ ট্র্যাকার</Text>
              <Text style={styles.menuSub}>ভার্সন 1.0.0</Text>
            </View>
          </View>
          <View style={styles.menuItem}>
            <Text style={styles.menuIcon}>👨‍💻</Text>
            <View style={styles.menuText}>
              <Text style={styles.menuTitle}>তৈরিকারক</Text>
              <Text style={styles.menuSub}>সজীবের জন্য বিশেষভাবে তৈরি</Text>
            </View>
          </View>
        </View>

        {/* Logout */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
            <Text style={styles.logoutText}>🚪 লগআউট করুন</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f9fafb" },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  headerTitle: { fontSize: 20, fontWeight: "800", color: "#111827" },
  scroll: { flex: 1 },
  section: { marginTop: 20, paddingHorizontal: 16 },
  sectionTitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#9ca3af",
    textTransform: "uppercase",
    letterSpacing: 1,
    marginBottom: 8,
    paddingLeft: 4,
  },
  profileCard: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    borderWidth: 1,
    borderColor: "#f3f4f6",
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: { color: "#fff", fontSize: 20, fontWeight: "700" },
  email: { fontSize: 16, fontWeight: "700", color: "#111827" },
  role: { fontSize: 12, color: "#6b7280", marginTop: 2 },
  menuItem: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#f3f4f6",
  },
  menuIcon: { fontSize: 20 },
  menuText: { flex: 1 },
  menuTitle: { fontSize: 15, fontWeight: "600", color: "#111827" },
  menuSub: { fontSize: 12, color: "#6b7280", marginTop: 2 },
  menuArrow: { fontSize: 20, color: "#9ca3af" },
  logoutBtn: {
    backgroundColor: "#fef2f2",
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#fecaca",
  },
  logoutText: { color: "#dc2626", fontWeight: "700", fontSize: 15 },
});
