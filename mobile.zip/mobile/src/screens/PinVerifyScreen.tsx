import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Alert,
  SafeAreaView,
  BackHandler,
} from "react-native";
import { useEffect } from "react";
import PinPad from "../components/PinPad";
import { useDevicePin } from "../hooks/useDevicePin";

interface Props {
  onVerified: () => void;
}

export default function PinVerifyScreen({ onVerified }: Props) {
  const [attempts, setAttempts] = useState(0);
  const { verifyPin } = useDevicePin();

  useEffect(() => {
    const handler = BackHandler.addEventListener("hardwareBackPress", () => true);
    return () => handler.remove();
  }, []);

  const handlePin = async (pin: string) => {
    const isValid = await verifyPin(pin);
    if (isValid) {
      onVerified();
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);

      if (newAttempts >= 3) {
        Alert.alert(
          "লক হয়ে গেছে",
          "অনেক বেশি ভুল চেষ্টা। অ্যাপ বন্ধ করুন এবং আবার চালু করুন।"
        );
      } else {
        Alert.alert("ভুল পিন", `${3 - newAttempts} টি চেষ্টা বাকি`);
      }
    }
  };

  const locked = attempts >= 3;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.iconContainer}>
        <Text style={styles.icon}>{locked ? "🔐" : "🔒"}</Text>
      </View>

      {locked ? (
        <View style={styles.lockedContainer}>
          <Text style={styles.lockedTitle}>অ্যাপ লক হয়ে গেছে</Text>
          <Text style={styles.lockedSubtitle}>
            অনেক বেশি ভুল চেষ্টা। অ্যাপ বন্ধ করে আবার চালু করুন।
          </Text>
        </View>
      ) : (
        <PinPad
          onComplete={handlePin}
          title="পিন কোড প্রবেশ করুন"
          subtitle={
            attempts > 0
              ? `ভুল পিন। ${3 - attempts} চেষ্টা বাকি`
              : "এই ডিভাইসের পিন কোড দিন"
          }
        />
      )}

      <Text style={styles.note}>শুধুমাত্র এই ডিভাইসে অ্যাক্সেস অনুমোদিত</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fef2f2",
    alignItems: "center",
    justifyContent: "center",
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  icon: {
    fontSize: 36,
  },
  lockedContainer: {
    alignItems: "center",
    paddingHorizontal: 40,
    marginTop: 24,
  },
  lockedTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#dc2626",
    textAlign: "center",
    marginBottom: 12,
  },
  lockedSubtitle: {
    fontSize: 14,
    color: "#6b7280",
    textAlign: "center",
    lineHeight: 22,
  },
  note: {
    fontSize: 12,
    color: "#9ca3af",
    marginTop: 24,
    textAlign: "center",
    paddingHorizontal: 32,
  },
});
