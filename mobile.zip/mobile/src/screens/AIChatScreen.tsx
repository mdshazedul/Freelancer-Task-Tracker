import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
} from "react-native";
import { trpc } from "../api/client";

type Role = "system" | "user" | "assistant";

interface Message {
  role: Role;
  content: string;
}

const SYSTEM_PROMPT = `তুমি "কাজ ট্র্যাকার" অ্যাপের AI সহকারী। তোমার নাম "সহায়"। তুমি সজীবের ফ্রিল্যান্সিং যাত্রায় সাহায্য করো।

তুমি যে বিষয়গুলোতে সাহায্য করতে পারো:
- ফ্রিল্যান্সিং ক্যারিয়ার পরামর্শ
- কাজ ও দক্ষতা ট্র্যাকিং কৌশল
- প্রোগ্রামিং ও ওয়েব ডেভেলপমেন্ট
- প্রজেক্ট ম্যানেজমেন্ট
- কাজের অগ্রগতি মূল্যায়ন

সবসময় বাংলায় উত্তর দাও। সহজ, পরিষ্কার ও উৎসাহব্যঞ্জক ভাষায় কথা বলো।`;

const SUGGESTED_PROMPTS = [
  "ফ্রিল্যান্সিং শুরু করার টিপস দাও",
  "আমার কাজ কীভাবে ট্র্যাক করব?",
  "নতুন দক্ষতা শেখার পরিকল্পনা করো",
  "ক্লায়েন্ট খোঁজার উপায় বলো",
];

export default function AIChatScreen() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "system", content: SYSTEM_PROMPT },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  const chatMutation = trpc.ai.chat.useMutation();

  const displayMessages = messages.filter((m) => m.role !== "system");

  const scrollToBottom = useCallback(() => {
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, []);

  useEffect(() => {
    if (displayMessages.length > 0) scrollToBottom();
  }, [displayMessages.length]);

  const handleSend = useCallback(
    async (text?: string) => {
      const content = (text ?? input).trim();
      if (!content || isLoading) return;

      const userMessage: Message = { role: "user", content };
      const newMessages = [...messages, userMessage];
      setMessages(newMessages);
      setInput("");
      setIsLoading(true);
      scrollToBottom();

      try {
        const response = await chatMutation.mutateAsync({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
        });
        const assistantMessage: Message = {
          role: "assistant",
          content: response.content,
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } catch (error) {
        Alert.alert("ত্রুটি", "AI উত্তর দিতে ব্যর্থ হয়েছে। আবার চেষ্টা করুন।");
        setMessages((prev) => prev.slice(0, -1));
      } finally {
        setIsLoading(false);
      }
    },
    [input, isLoading, messages, chatMutation, scrollToBottom]
  );

  const handleClear = () => {
    Alert.alert("চ্যাট মুছুন", "সব কথোপকথন মুছে ফেলবেন?", [
      { text: "না", style: "cancel" },
      {
        text: "হ্যাঁ",
        onPress: () =>
          setMessages([{ role: "system", content: SYSTEM_PROMPT }]),
      },
    ]);
  };

  const renderMessage = ({ item, index }: { item: Message; index: number }) => {
    const isUser = item.role === "user";
    return (
      <View
        style={[
          styles.messageRow,
          isUser ? styles.messageRowUser : styles.messageRowAI,
        ]}
      >
        {!isUser && (
          <View style={styles.aiAvatar}>
            <Text style={styles.aiAvatarText}>✨</Text>
          </View>
        )}
        <View
          style={[
            styles.bubble,
            isUser ? styles.bubbleUser : styles.bubbleAI,
          ]}
        >
          <Text style={isUser ? styles.bubbleUserText : styles.bubbleAIText}>
            {item.content}
          </Text>
        </View>
        {isUser && (
          <View style={styles.userAvatar}>
            <Text style={styles.userAvatarText}>স</Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View style={styles.headerIcon}>
            <Text style={styles.headerIconText}>✨</Text>
          </View>
          <View>
            <Text style={styles.headerTitle}>সহায় AI</Text>
            <Text style={styles.headerSub}>আপনার ফ্রিল্যান্সিং সহকারী</Text>
          </View>
        </View>
        {displayMessages.length > 0 && (
          <TouchableOpacity style={styles.clearBtn} onPress={handleClear}>
            <Text style={styles.clearBtnText}>🗑 মুছুন</Text>
          </TouchableOpacity>
        )}
      </View>

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        {/* Messages */}
        {displayMessages.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>✨</Text>
            <Text style={styles.emptyTitle}>সহায় AI-এর সাথে কথা বলুন</Text>
            <Text style={styles.emptySub}>
              ফ্রিল্যান্সিং, কাজ ট্র্যাকিং বা দক্ষতা নিয়ে যেকোনো প্রশ্ন করুন
            </Text>
            <View style={styles.suggestedList}>
              {SUGGESTED_PROMPTS.map((prompt, i) => (
                <TouchableOpacity
                  key={i}
                  style={styles.suggestedChip}
                  onPress={() => handleSend(prompt)}
                >
                  <Text style={styles.suggestedChipText}>{prompt}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={displayMessages}
            keyExtractor={(_, i) => String(i)}
            renderItem={renderMessage}
            contentContainerStyle={styles.messageList}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={scrollToBottom}
            ListFooterComponent={
              isLoading ? (
                <View style={[styles.messageRow, styles.messageRowAI]}>
                  <View style={styles.aiAvatar}>
                    <Text style={styles.aiAvatarText}>✨</Text>
                  </View>
                  <View style={[styles.bubble, styles.bubbleAI, styles.loadingBubble]}>
                    <ActivityIndicator size="small" color="#dc2626" />
                    <Text style={styles.loadingText}>লিখছে...</Text>
                  </View>
                </View>
              ) : null
            }
          />
        )}

        {/* Input */}
        <View style={styles.inputArea}>
          <TextInput
            style={styles.input}
            placeholder="বার্তা লিখুন..."
            placeholderTextColor="#9ca3af"
            value={input}
            onChangeText={setInput}
            multiline
            maxLength={2000}
            returnKeyType="send"
            onSubmitEditing={() => handleSend()}
            blurOnSubmit={false}
          />
          <TouchableOpacity
            style={[
              styles.sendBtn,
              (!input.trim() || isLoading) && styles.sendBtnDisabled,
            ]}
            onPress={() => handleSend()}
            disabled={!input.trim() || isLoading}
          >
            {isLoading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.sendBtnText}>➤</Text>
            )}
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#f9fafb" },
  flex: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  headerIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#fef2f2",
    alignItems: "center",
    justifyContent: "center",
  },
  headerIconText: { fontSize: 22 },
  headerTitle: { fontSize: 17, fontWeight: "700", color: "#111827" },
  headerSub: { fontSize: 12, color: "#6b7280", marginTop: 1 },
  clearBtn: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
    backgroundColor: "#f3f4f6",
  },
  clearBtnText: { fontSize: 12, color: "#6b7280", fontWeight: "500" },

  emptyState: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
    gap: 12,
  },
  emptyIcon: { fontSize: 52, marginBottom: 4 },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
    textAlign: "center",
  },
  emptySub: {
    fontSize: 14,
    color: "#6b7280",
    textAlign: "center",
    lineHeight: 22,
  },
  suggestedList: {
    marginTop: 16,
    gap: 10,
    width: "100%",
    alignItems: "center",
  },
  suggestedChip: {
    backgroundColor: "#fff",
    borderWidth: 1.5,
    borderColor: "#e5e7eb",
    borderRadius: 22,
    paddingHorizontal: 18,
    paddingVertical: 10,
    width: "100%",
  },
  suggestedChipText: {
    fontSize: 13,
    color: "#374151",
    fontWeight: "500",
    textAlign: "center",
  },

  messageList: { padding: 16, paddingBottom: 8, gap: 12 },
  messageRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 8,
    marginBottom: 4,
  },
  messageRowUser: { justifyContent: "flex-end" },
  messageRowAI: { justifyContent: "flex-start" },
  aiAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#fef2f2",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  aiAvatarText: { fontSize: 16 },
  userAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  userAvatarText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  bubble: {
    maxWidth: "78%",
    borderRadius: 18,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  bubbleUser: {
    backgroundColor: "#dc2626",
    borderBottomRightRadius: 4,
  },
  bubbleAI: {
    backgroundColor: "#fff",
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: "#f3f4f6",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  bubbleUserText: { color: "#fff", fontSize: 14, lineHeight: 21 },
  bubbleAIText: { color: "#111827", fontSize: 14, lineHeight: 21 },
  loadingBubble: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 12,
  },
  loadingText: { fontSize: 13, color: "#6b7280" },

  inputArea: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#f3f4f6",
    gap: 10,
  },
  input: {
    flex: 1,
    backgroundColor: "#f9fafb",
    borderWidth: 1.5,
    borderColor: "#e5e7eb",
    borderRadius: 22,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 14,
    color: "#111827",
    maxHeight: 120,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#dc2626",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  sendBtnDisabled: { backgroundColor: "#fca5a5" },
  sendBtnText: { color: "#fff", fontSize: 18, fontWeight: "700" },
});
