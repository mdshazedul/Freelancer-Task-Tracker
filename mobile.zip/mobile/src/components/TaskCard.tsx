import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { format } from "date-fns";
import type { Task, Category, FileData } from "../types";

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  isPending?: boolean;
}

const getCategoryColor = (category: Category) => {
  switch (category) {
    case "learned":
      return { bg: "#dcfce7", text: "#166534" };
    case "completed":
      return { bg: "#fee2e2", text: "#991b1b" };
    case "in-progress":
      return { bg: "#fef9c3", text: "#854d0e" };
  }
};

const getCategoryLabel = (category: Category) => {
  switch (category) {
    case "learned": return "শেখা";
    case "completed": return "সম্পন্ন";
    case "in-progress": return "চলমান";
  }
};

const getTaskFiles = (task: Task): FileData[] => {
  if (!task.filesData) return [];
  try {
    return JSON.parse(task.filesData);
  } catch {
    return [];
  }
};

export default function TaskCard({ task, onEdit, onDelete, isPending = false }: TaskCardProps) {
  const catColor = getCategoryColor(task.category);
  const taskFiles = getTaskFiles(task);
  const images = taskFiles.filter((f) => f.type === "image");
  const videos = taskFiles.filter((f) => f.type === "video");

  let dateText = "";
  try {
    dateText = format(new Date(task.taskDate), "dd MMM yyyy");
  } catch {
    dateText = String(task.taskDate).slice(0, 10);
  }

  return (
    <View style={[styles.card, isPending && styles.cardPending]}>
      {isPending && (
        <View style={styles.pendingBadge}>
          <Text style={styles.pendingBadgeText}>⏳ পেন্ডিং সিঙ্ক</Text>
        </View>
      )}
      <View style={styles.header}>
        <View style={styles.titleArea}>
          <Text style={[styles.title, isPending && styles.titlePending]} numberOfLines={2}>
            {task.title}
          </Text>
          <Text style={styles.date}>{dateText}</Text>
        </View>
        <View style={[styles.badge, { backgroundColor: catColor.bg }]}>
          <Text style={[styles.badgeText, { color: catColor.text }]}>
            {getCategoryLabel(task.category)}
          </Text>
        </View>
      </View>

      {task.description ? (
        <Text style={styles.description} numberOfLines={2}>
          {task.description}
        </Text>
      ) : null}

      {(images.length > 0 || videos.length > 0) && (
        <View style={styles.fileRow}>
          {images.length > 0 && (
            <View style={styles.fileChip}>
              <Text style={styles.fileChipText}>🖼 {images.length}</Text>
            </View>
          )}
          {videos.length > 0 && (
            <View style={[styles.fileChip, styles.videoChip]}>
              <Text style={[styles.fileChipText, styles.videoChipText]}>
                🎬 {videos.length}
              </Text>
            </View>
          )}
        </View>
      )}

      <View style={styles.actions}>
        <TouchableOpacity
          style={[styles.btn, styles.editBtn, isPending && styles.btnDisabled]}
          onPress={() => onEdit(task)}
        >
          <Text style={styles.editBtnText}>✏️ সম্পাদনা</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.btn, styles.deleteBtn]}
          onPress={() => onDelete(task.id)}
        >
          <Text style={styles.deleteBtnText}>🗑 মুছুন</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 8,
    elevation: 3,
  },
  cardPending: {
    borderWidth: 1.5,
    borderColor: "#fbbf24",
    backgroundColor: "#fffbeb",
  },
  pendingBadge: {
    backgroundColor: "#fef3c7",
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
    alignSelf: "flex-start",
    marginBottom: 8,
  },
  pendingBadgeText: {
    fontSize: 11,
    color: "#92400e",
    fontWeight: "600",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 8,
    gap: 8,
  },
  titleArea: { flex: 1 },
  title: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 2,
  },
  titlePending: { color: "#78350f" },
  date: { fontSize: 12, color: "#9ca3af" },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  badgeText: { fontSize: 12, fontWeight: "600" },
  description: {
    fontSize: 14,
    color: "#6b7280",
    marginBottom: 10,
    lineHeight: 20,
  },
  fileRow: { flexDirection: "row", gap: 8, marginBottom: 12 },
  fileChip: {
    backgroundColor: "#dbeafe",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  fileChipText: { fontSize: 12, color: "#1d4ed8" },
  videoChip: { backgroundColor: "#fee2e2" },
  videoChipText: { color: "#991b1b" },
  actions: { flexDirection: "row", gap: 8, marginTop: 4 },
  btn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 10,
    alignItems: "center",
  },
  btnDisabled: { opacity: 0.5 },
  editBtn: { backgroundColor: "#f3f4f6" },
  editBtnText: { fontSize: 13, fontWeight: "600", color: "#374151" },
  deleteBtn: { backgroundColor: "#fff1f2" },
  deleteBtnText: { fontSize: 13, fontWeight: "600", color: "#dc2626" },
});
