import React, { useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  Animated,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";

interface Props {
  isOnline: boolean;
  isSyncing: boolean;
  pendingCount: number;
  onSyncPress?: () => void;
}

export default function OfflineBanner({ isOnline, isSyncing, pendingCount, onSyncPress }: Props) {
  const slideAnim = useRef(new Animated.Value(-60)).current;

  const visible = !isOnline || isSyncing || pendingCount > 0;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: visible ? 0 : -60,
      useNativeDriver: true,
      tension: 80,
      friction: 10,
    }).start();
  }, [visible, slideAnim]);

  if (!visible) return null;

  const bgColor = isSyncing
    ? "#2563eb"
    : !isOnline
    ? "#dc2626"
    : "#16a34a";

  const message = isSyncing
    ? `সার্ভারে সিঙ্ক হচ্ছে...`
    : !isOnline && pendingCount > 0
    ? `অফলাইন — ${pendingCount}টি পরিবর্তন পেন্ডিং`
    : !isOnline
    ? "অফলাইন — ক্যাশ থেকে দেখাচ্ছে"
    : `${pendingCount}টি পরিবর্তন সিঙ্ক হচ্ছে`;

  return (
    <Animated.View
      style={[styles.banner, { backgroundColor: bgColor }, { transform: [{ translateY: slideAnim }] }]}
    >
      <View style={styles.left}>
        {isSyncing ? (
          <ActivityIndicator size="small" color="#fff" style={styles.icon} />
        ) : (
          <Text style={styles.dot}>{!isOnline ? "📵" : "✅"}</Text>
        )}
        <Text style={styles.text}>{message}</Text>
      </View>
      {!isOnline && pendingCount > 0 && onSyncPress && isOnline && (
        <TouchableOpacity onPress={onSyncPress} style={styles.retryBtn}>
          <Text style={styles.retryText}>সিঙ্ক</Text>
        </TouchableOpacity>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  banner: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  left: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flex: 1,
  },
  dot: { fontSize: 14 },
  icon: { marginRight: 4 },
  text: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "600",
    flexShrink: 1,
  },
  retryBtn: {
    backgroundColor: "rgba(255,255,255,0.25)",
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 8,
  },
  retryText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "700",
  },
});
